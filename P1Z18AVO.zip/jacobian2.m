function J = jacobian2(u, v, r)
% Project 1, zadanie 18
% Andrii Voznesenskyi, 323538

dx_du = r .* sqrt(1 - (v.^2)/2);
dx_dv = -r .* u .* v ./ sqrt(2 - v.^2);
dy_du = -r .* u .* v ./ sqrt(2 - u.^2);
dy_dv = r .* sqrt(1 - (u.^2)/2);

J = dx_du .* dy_dv - dx_dv .* dy_du;
J(J == 0) = eps;
end