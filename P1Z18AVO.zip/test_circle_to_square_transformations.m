function test_circle_to_square_transformations()
    num_points = 100000;
    fprintf('This function demonstrates two transformations that convert a set of points \n');
    fprintf('from a circular distribution to a square distribution. \n');
    fprintf('A total of %d random points are generated within a unit circle \n', num_points);
    fprintf('using polar coordinates (r, theta) where r is the radius and theta is the angle. \n');
    fprintf('These points are then converted into Cartesian coordinates (u, v) \n');
    fprintf('before being transformed by two different methods into a square distribution.\n');
    fprintf('The resulting distributions are plotted side by side for comparison.\n\n');

    
    theta = 2 * pi * rand(num_points, 1); % Random angle
    r = sqrt(rand(num_points, 1)); % Random radius in [0,1)
    u = r .* cos(theta); % Convert polar to Cartesian coordinates for u
    v = r .* sin(theta); % Convert polar to Cartesian coordinates for v

    % First transformation
    [x1, y1] = transform_circle_to_square(u, v);

    % Second transformation
    [x2, y2] = transform_circle_to_square2(u, v, r);

    % Plotting both transformations
    figure; % Create a new figure

    % Plot the first transformation
    subplot(1, 2, 1); % Create a subplot (1 row, 2 columns, first plot)
    scatter(x1, y1, 1, '.'); % Plot the transformed points with a dot size of 1
    axis equal; % Set axes to have equal length
    title('First Transformation from Circle to Square');
    xlabel('X');
    ylabel('Y');

    % Plot the second transformation
    subplot(1, 2, 2); % Create a subplot (1 row, 2 columns, second plot)
    scatter(x2, y2, 1, '.'); % Plot the transformed points with a dot size of 1
    axis equal; % Set axes to have equal length
    title('Second Transformation(squircular) from Circle to Square');
    xlabel('X');
    ylabel('Y');
end